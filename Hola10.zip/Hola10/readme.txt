==================================================================================================

DESCRIPTION:

HOLA is a modern and stylish vCard website template. Designed to be a resume, vCard, portfolio 
template, it's the perfect template for creative designers, developers, freelancers, photographer 
or any creative profession. It is fully responsive and retina/hi-dpi ready. It will look great 
on any devices from desktop to mobile phones. It has blog page templates, working contact form, 
stylish portfolio section and other features you will only find on premium templates. Built with 
clean and organized code, this template is also very easy to customize.

==================================================================================================


LICENSE:


HOLA is released under the Creative Commons Attribution 3.0 License
(http://creativecommons.org/licenses/by/3.0/). This means that you are free:

   to Share - to copy, distribute, display, and perform the work
   to Remix - to make derivative works
   to make commercial use of the work 

Under the following conditions:

   Attribution - You must attribute the work in the manner specified by the 
   author or licensor (but not in any way that suggests that they endorse you 
   or your use of the work). 

   For any reuse or distribution, you must make clear to others the license 
   terms of this work

   Any of these conditions can be waived if you get permission from the 
   copyright holder

Attribution: 
	
   You must include a credit link to our website(https://www.Styleshout.com) somewhere on
   your site. We prefer the footer credit that comes with the template but you are still 
   free to move it somewhere else.


-----------------------------------------------------------------------------------------------------


REMOVING THE LINK:

We understand that there are situations where you want to use the template without the 
crediting obligation. If that's your case, you can always send us a 
credit removal fee of 10 USD through Paypal. This will allow you to use the 
template attribution/credit link free on ONE DOMAIN name. 

You can send your payments through Paypal to this address: ealigam@gmail.com

If possible, kindly send us the site's url where the template is being used. 
Also, keep your Paypal receipt as proof of payment and your good to go.


------------------------------------------------------------------------------------------------------ 


SUPPORT:
    
Since HOLA is distributed for free, support is not offered. HOLA is coded according 
to current web standards and we did our best to make the template easy to use and modify.
If you have minimum web development experience, you can easily modify the template. 
However, If you're still new to HTML and CSS, I suggest that you visit the 
following tutorials:

 - http://tutsplus.com/course/30-days-to-learn-html-and-css/
 - http://learn.shayhowe.com/html-css/

These will teach you the essentials of HTML and CSS. In addition, if you want to include
jQuery in your skill-set, you can also check out these tutorials: 

 - http://code.tutsplus.com/courses/30-days-to-learn-jquery
 - http://try.jquery.com/


------------------------------------------------------------------------------------------------------ 


GET THE LATEST VERSION:

We update our templates on a regular basis so to make sure that you have the latest version, 
always download the template files directly on our website(https://www.styleshout.com/)



-------------------------------------------------------------------------------------------------------


SOURCES AND CREDITS:

I've used the following resources as listed.

Fonts:
 - Montserrat Font (https://www.google.com/fonts/specimen/Montserrat)
 - Libre Baskerville Font (https://fonts.google.com/specimen/Libre+Baskerville) 

Icons:
 - Iconic font (https://iconmonstr.com/iconicfont/)

Stock Photos and Graphics:
 - Unsplash.com (https://unsplash.com/)
 - gratisography (https://gratisography.com/)
 
Javascript Files:

 - JQuery (http://jquery.com/)
 - Modernizr (http://modernizr.com/)
 - Waypoints (http://imakewebthings.com/jquery-waypoints/)
 - jQuery Placeholder (https://github.com/mathiasbynens/jquery-placeholder)
 - jQuery Validation Plugin (https://jqueryvalidation.org/)
 - pace js (http://github.hubspot.com/pace/)
 - Masonry (http://masonry.desandro.com/)
 - Imagesloaded (https://imagesloaded.desandro.com/)
 - Parallax.js (http://pixelcog.github.io/parallax.js/)
 - Slick Slider (http://kenwheeler.github.io/slick/)



-------------------------------------------------------------------------------------------------------


Thanks for downloading from Styleshout :)


